import { Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

class PostController {
    async listPosts(req: Request, res: Response) {
        try {
            const posts = await prisma.post.findMany();
            res.json(posts);
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: (error as Error).message || 'Erro desconhecido' });
        }
    }

    async createPost(req: Request, res: Response) {
        try {
            const postData = req.body;

            if (!postData.title) {
                return res.status(400).json({
                    status: 400,
                    message: "Você precisa passar o título no corpo da requisição",
                });
            }

            const newPost = await prisma.post.create({
                data: postData,
            });

            res.status(201).json({
                status: 201,
                newPost,
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: (error as Error).message || 'Erro desconhecido' });
        }
    }

    async updatePost(req: Request, res: Response) {
        try {
            const id = parseInt(req.params.id);
            const postData = req.body;

            const updatedPost = await prisma.post.update({
                where: { id },
                data: postData,
            });

            res.json({
                status: 200,
                updatedPost,
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: (error as Error).message || 'Erro desconhecido' });
        }
    }

    async deletePost(req: Request, res: Response) {
        try {
            const id = parseInt(req.params.id);

            await prisma.post.delete({
                where: { id },
            });

            res.status(200).json({
                status: 200,
                message: "Post deletado com sucesso",
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: (error as Error).message || 'Erro desconhecido' });
        }
    }
}

export default new PostController();
