import { Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

class UserController {
    async listUser(req: Request, res: Response) {
        try {
            const users = await prisma.user.findMany();
            res.json(users);
        } catch (error) {
            console.error(error);
            return res.status(500).json({
                error: (error as Error).message || 'Erro desconhecido'
            });
        }
    }

    async createUser(req: Request, res: Response) {
        try {
            const userdata = req.body;
        
            if (!userdata.email) {
                return res.status(400).json({
                    status: 400,
                    message: "Você precisa passar o email no corpo da requisição",
                });
            }
        
            const newuser = await prisma.user.create({
                data: userdata,
            });
        
            res.json({
                status: 200,
                newuser: newuser,
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                status: 500,
                message: (error as Error).message || 'Erro desconhecido',
            });
        }
    }

    async updateUser(req: Request, res: Response) {
        try {
            const id = parseInt(req.params.id);
            const body = req.body;
        
            const updatedUser = await prisma.user.update({
                where: { id },
                data: body,
            });
        
            return res.json({
                status: 200,
                updatedUser: updatedUser,
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                status: 500,
                message: (error as Error).message || 'Erro desconhecido',
            });
        }
    }

    async deleteUser(req: Request, res: Response) {
        try {
            const id = parseInt(req.params.id);
        
            await prisma.user.delete({
                where: { id },
            });
        
            res.status(200).json({
                status: 200,
                message: "Usuário deletado com sucesso",
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                status: 500,
                message: (error as Error).message || 'Erro desconhecido',
            });
        }
    }
}

export default new UserController();
