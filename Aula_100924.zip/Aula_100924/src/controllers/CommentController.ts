import { Request, Response } from "express";
import { PrismaClient } from "@prisma/client";
import axios from 'axios'; // Adicione esta importação

const prisma = new PrismaClient();

const GROQCLOUD_API_URL = process.env.GROQCLOUD_API_URL!;
const GROQCLOUD_API_KEY = process.env.GROQCLOUD_API_KEY!;

async function checkCommentForOffensiveness(comment: string): Promise<boolean> {
    try {
        const response = await axios.post(GROQCLOUD_API_URL, {
            text: comment
        }, {
            headers: {
                'Authorization': `Bearer ${GROQCLOUD_API_KEY}`,
                'Content-Type': 'application/json'
            }
        });

        return response.data.isOffensive; // Ajuste conforme a resposta da API
    } catch (error) {
        console.error('Erro ao verificar o comentário:', error);
        throw new Error('Erro ao verificar o comentário.');
    }
}

class CommentController {
    async listComments(req: Request, res: Response) {
        try {
            const comments = await prisma.comment.findMany();
            res.json(comments);
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: (error as Error).message || 'Erro desconhecido' });
        }
    }

    async createComment(req: Request, res: Response) {
        try {
            const { title, content, authorId, postId } = req.body;

            if (!content) {
                return res.status(400).json({
                    status: 400,
                    message: "Você precisa passar o conteúdo no corpo da requisição",
                });
            }

            // Verificar se o comentário é ofensivo
            const isOffensive = await checkCommentForOffensiveness(content);
            if (isOffensive) {
                return res.status(400).json({
                    status: 400,
                    message: "Comentário ofensivo detectado.",
                });
            }

            // Criar o novo comentário
            const newComment = await prisma.comment.create({
                data: {
                    title,
                    content,
                    authorId,
                    postId,
                },
            });

            res.status(201).json({
                status: 201,
                newComment,
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: (error as Error).message || 'Erro desconhecido' });
        }
    }

    async updateComment(req: Request, res: Response) {
        try {
            const id = parseInt(req.params.id);
            const commentData = req.body;

            const updatedComment = await prisma.comment.update({
                where: { id },
                data: commentData,
            });

            res.json({
                status: 200,
                updatedComment,
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: (error as Error).message || 'Erro desconhecido' });
        }
    }

    async deleteComment(req: Request, res: Response) {
        try {
            const id = parseInt(req.params.id);

            await prisma.comment.delete({
                where: { id },
            });

            res.status(200).json({
                status: 200,
                message: "Comentário deletado com sucesso",
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: (error as Error).message || 'Erro desconhecido' });
        }
    }
}

export default new CommentController();
